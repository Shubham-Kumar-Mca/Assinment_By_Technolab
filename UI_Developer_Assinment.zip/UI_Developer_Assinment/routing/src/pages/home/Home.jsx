import React from 'react'
import "./Home.css"

const Home = () => {
  return (
    <div className='home'>
        <h1>Welcome to Home Page</h1>
    </div>
  )
}

export default Home