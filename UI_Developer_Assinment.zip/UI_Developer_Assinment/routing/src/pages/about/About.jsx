import React from 'react'
import "./About.css"

const About = () => {
  return (
    <div className='about'>
        <h1>Welcome to About Page</h1>
    </div>
  )
}

export default About